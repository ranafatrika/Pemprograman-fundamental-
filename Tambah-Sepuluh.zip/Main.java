class Main {
  public static void main(String[] args) {
    int nilai = (8 + 10);
    System.out.println(nilai);
  }
}