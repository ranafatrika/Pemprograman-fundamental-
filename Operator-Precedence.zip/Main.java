class Main {
    public static void main(String[] args) {
        boolean satu = true;
        boolean dua = false;
        
        boolean hasil1 = satu & dua;
        
        System.out.println(hasil1);
    }
}