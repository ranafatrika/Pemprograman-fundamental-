class Main {
  public static void main(String[] args) {
    sayaBerjanji();
  }
  
  private static void sayaBerjanji() {
    for (int i = 0; i < 20; i++) {
        System.out.println("Saya berjanji akan rajin belajar Java!");
    }
  }
}