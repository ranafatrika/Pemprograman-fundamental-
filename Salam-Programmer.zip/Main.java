class Main {
  public static void main(String[] args) {
    String salam = "Salam Programmer! Selamat belajar Java!";
    System.out.println("Salam Programmer! Selamat belajar Java!");
    System.out.println("Salam Programmer! Selamat belajar Java!");
    System.out.println("Salam Programmer! Selamat belajar Java!");
  }
}